#!/bin/bash

function print_color() {
  local color=$1
  shift
  echo -e "\033[${color}m$@\033[0m"
}

# 检查用户是否为root用户
if [ $(id -u) != 0 ]; then
    echo "\n请使用root权限执行 !"
    exit 1
fi

sleep 0.3

echo -e "\033[1;33;40mTG-:@YOUYYDA\033[0m"
echo -e "\033[33;31m**************************************\033[0m"   	

sleep 0.2

cp -f libYOU.so /data/data/com.tencent.ig/
chmod 755 /data/data/com.tencent.ig/libYOU.so*

cp -f inject /data/data/com.tencent.ig/
chmod 777 /data/data/com.tencent.ig/inject*

# 检查文件是否存在并且权限为755
if [ -f /data/data/com.tencent.ig/libYOU.so ] && [ "$(stat -c '%a' /data/data/com.tencent.ig/libYOU.so)" = "755" ]; then
    echo "[+] 动态库文件正常"
else
    echo "[-] 动态库文件不正确"
    exit 1
fi

if [ -f /data/data/com.tencent.ig/inject ] && [ "$(stat -c '%a' /data/data/com.tencent.ig/inject)" = "777" ]; then
    echo "[+] 劫持文件正常"
else
    echo "[-] 劫持文件不正确"
    exit 1
fi

echo -e "\n"

print_color 41 "准备完毕!"

echo -e "\n"

sleep 0.5

am start com.tencent.ig/com.epicgames.ue4.SplashActivity

sleep 2.0

echo -e "\n"

su -c /data/data/com.tencent.ig/inject -n com.tencent.igce -so /data/data/com.tencent.ig/libYOU.so